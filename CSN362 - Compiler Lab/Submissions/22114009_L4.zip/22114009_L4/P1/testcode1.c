int main()
{
    int a=10,20;
    charch;
    float f;
}