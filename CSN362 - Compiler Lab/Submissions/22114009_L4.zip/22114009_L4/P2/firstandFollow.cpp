#include<bits/stdc++.h>
using namespace std;

#define MAX_PRODUCTIONS 10
#define MAX_PRODUCTION_LENGTH 10

#define MAX_NON_TERMINALS 10
#define MAX_SET_SIZE 100

#define MAX_TEMPO_SIZE 10

void FindFollowAndFirst(char, int, int);
void follow(char c);

void findfirst(char, int, int);

int numProductions, n = 0;

char calc_first[MAX_NON_TERMINALS][MAX_SET_SIZE];

char calc_follow[MAX_NON_TERMINALS][MAX_SET_SIZE];
int m = 0;

char production[MAX_PRODUCTIONS][MAX_PRODUCTION_LENGTH];
char f[MAX_TEMPO_SIZE], first[MAX_TEMPO_SIZE];
int k, e;
char ck;

int main(int argc, char** argv) {
    int jm = 0, km = 0;
    int i, choice;
    char c, ch;

    cout << "Following assumptions have been made :\n1. Epsilon is represented by the symbol #.\n2. '$' is a marker symbol to denote the end of the input stream.\n3. Upper Case letters are Non-Terminals and everything else is a terminal.\n" << endl;

    cout<<"Enter the no. of productions : ";
    cin>>numProductions;

    cout<<"Enter a '$' symbol when the number of productions finish early.\n";
    cout<<"Enter the productions : \n";

    string line;
    vector<string> production_rules;

    int production_count = 0;

    auto process_input = [&] (string &str, char &non_term, int iter) {
        string prod;

        for(int i = iter; i < (int)str.length(); i++) {
            char ch = str[i];
            if(ch == ' ') continue;
            if(ch == '|') {
                production_rules.push_back(string(1, non_term) + "=" + prod);
                production_count++;
                prod.clear();
            }
            else prod.push_back(ch);
        }

        if(!prod.empty()) {
            production_rules.push_back(string(1, non_term) + "=" + prod);
            production_count++;
        }    
    };

    while(getline(cin, line)) {
        if(line.empty()) continue;
        if(line == "$") break;

        int non_term_index = 0, iter = 0;
        while(true) {
            if(line[iter] == ' ') {
                iter++;
                continue;
            }
            if(line[iter] == '-') {
                iter++;
                iter++;
                break;
            }
            else {
                non_term_index = iter;
                iter++;
            }
        }

        char non_term = line[non_term_index];
        process_input(line, non_term, iter);

        if(production_count > numProductions) {
            cout<<"Error! Number of production rules exceeds the count of "<<numProductions<<" production rules entered above";
            exit(1);
        }
        else if(production_count == numProductions) {
            break;
        }
    }

    for(int i = 0; i < production_count; i++) {
        for(int j = 0; j < production_rules[i].size(); j++) {
            production[i][j] = production_rules[i][j];
        }
    }

    int kay;
    char done[numProductions];
    int ptr = -1;

    for (k = 0; k < numProductions; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_first[k][kay] = '!';
        }
    }
    int point1 = 0, point2, zzz;

    for (k = 0; k < numProductions; k++) {
        c = production[k][0];
        point2 = 0;
        zzz = 0;

        for (kay = 0; kay <= ptr; kay++)
            if (c == done[kay])
                zzz = 1;

        if (zzz == 1)
            continue;

        findfirst(c, 0, 0);
        ptr += 1;

        done[ptr] = c;
        if (!c) {
            continue;
        }
        printf("\n First(%c) = { ", c);
        calc_first[point1][point2++] = c;

        for (i = 0 + jm; i < n; i++) {
            int lark = 0, chk = 0;

            for (lark = 0; lark < point2; lark++) {

                if (first[i] == calc_first[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                printf("%c, ", first[i]);
                calc_first[point1][point2++] = first[i];
            }
        }
        printf("}\n");
        jm = n;
        point1++;
    }

    printf("\n");
    printf("-----------------------------------------------""\n\n");
           
    char donee[numProductions];
    ptr = -1;

    for (k = 0; k < numProductions; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_follow[k][kay] = '!';
        }
    }
    point1 = 0;
    int land = 0;
    for (e = 0; e < numProductions; e++) {
        ck = production[e][0];
        point2 = 0;
        zzz = 0;

        for (kay = 0; kay <= ptr; kay++)
            if (ck == donee[kay])
                zzz = 1;

        if (zzz == 1)
            continue;
        land += 1;

        follow(ck);
        ptr += 1;

        donee[ptr] = ck;
        printf(" Follow(%c) = { ", ck);
        calc_follow[point1][point2++] = ck;

        for (i = 0 + km; i < m; i++) {
            int lark = 0, chk = 0;
            for (lark = 0; lark < point2; lark++) {
                if (f[i] == calc_follow[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                printf("%c, ", f[i]);
                calc_follow[point1][point2++] = f[i];
            }
        }
        printf(" }\n\n");
        km = m;
        point1++;
    }
}

void follow(char c)
{
    int i, j;

    if (production[0][0] == c) {
        f[m++] = '$';
    }
    for (i = 0; i < MAX_PRODUCTIONS; i++) {
        for (j = 2; j < MAX_PRODUCTION_LENGTH; j++) {
            if (production[i][j] == c) {
                if (production[i][j + 1] != '\0') {
                    FindFollowAndFirst(production[i][j + 1], i,
                                (j + 2));
                }

                if (production[i][j + 1] == '\0'
                    && c != production[i][0]) {
                    follow(production[i][0]);
                }
            }
        }
    }
}

void findfirst(char c, int q1, int q2)
{
    int j;

    if (!(isupper(c))) {
        first[n++] = c;
    }
    for (j = 0; j < numProductions; j++) {
        if (production[j][0] == c) {
            if (production[j][2] == '#') {
                if (production[q1][q2] == '\0')
                    first[n++] = '#';
                else if (production[q1][q2] != '\0'
                         && (q1 != 0 || q2 != 0)) {
                    findfirst(production[q1][q2], q1,
                              (q2 + 1));
                }
                else
                    first[n++] = '#';
            }
            else if (!isupper(production[j][2])) {
                first[n++] = production[j][2];
            }
            else {
                findfirst(production[j][2], j, 3);
            }
        }
    }
}

void FindFollowAndFirst(char c, int c1, int c2)
{
    int k;

    if (!(isupper(c)))
        f[m++] = c;
    else {
        int i = 0, j = 1;
        for (i = 0; i < numProductions; i++) {
            if (calc_first[i][0] == c)
                break;
        }

        while (calc_first[i][j] != '!') {
            if (calc_first[i][j] != '#') {
                f[m++] = calc_first[i][j];
            }
            else {
                if (production[c1][c2] == '\0') {
                    follow(production[c1][0]);
                }
                else {
                    FindFollowAndFirst(production[c1][c2], c1,
                                c2 + 1);
                }
            }
            j++;
        }
    }
}

