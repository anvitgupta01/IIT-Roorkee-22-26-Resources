#include <bits/stdc++.h>

// Left recusrion is not present in the grammar

#define EPSILON(x) (x == '^')

#define expectedsep(x) if(x != "->") { std::cerr << "Invalid production: " << line << std::endl; std::cerr << "Please remove any spaces before and after ->" << std::endl; return 1; }
#define expectedupper(x) if(!isupper(x)) { std::cerr << "Invalid production: " << line << std::endl; std::cerr << "Rule should start with a non terminal" << std::endl; return 1; }

void compute_first(std::map<char, std::vector<std::vector<char>>>& prods, std::map<char, std::set<char>> &first, char nt, std::map<char, bool>& done) {
    if(done[nt]) return;
    for(auto prod : prods[nt]) {
        int num_eps = 0;
        for(auto ch : prod) {

            if(ch == nt) {
                if(first[ch].find('^') != first[ch].end()) {
                    num_eps++;
                }
                continue;
            }

            if(isupper(ch)) {
                compute_first(prods, first, ch, done);
                bool is_eps = false;
                for(char c : first[ch]) {
                    if(EPSILON(c)) {
                        is_eps = true;
                        continue;
                    }
                    first[nt].insert(c);
                }
                if(is_eps) {
                    num_eps++;
                } else {
                    break;
                }
                continue;
            }

            break;
        }
        if(num_eps == prod.size()) {
            first[nt].insert('^');
        }
    }
    done[nt] = true;
}

void compute_follow(std::map<char, std::vector<std::vector<char>>>& prods, std::map<char, std::set<char>> &follow, std::map<char, std::set<char>> &first, char nt) {
    for(auto prod : prods[nt]) {
        for(int i = prod.size() - 1; i >= 0; i--) {

            if(prod[i] == nt) {
                if(first[nt].find('^') != first[nt].end()) {
                    continue;
                }
                break;
            }

            if(isupper(prod[i])) {
                for(char ch: follow[nt]) {
                    follow[prod[i]].insert(ch);
                }
                if(first[prod[i]].find('^') != first[prod[i]].end()) {
                    continue;
                }
            }
            break;
        }
    }
}

int main() {
    std::map<char, std::vector<std::vector<char>>> prods;
    std::map<char, std::set<char>> first;
    std::map<char, std::set<char>> follow;
    std::map<char, bool> done;

    std::string filename;
    std::cout << "Enter the filename containing grammar : "<<std::endl;
    std::cin >> filename;
    std::cin.ignore();

    std::string line;
    char ssl;

    std::ifstream fin;
    fin.open(filename); 
    int i = -1;
    while(getline(fin, line)) {
        i++;
        expectedupper(line[0])
        expectedsep(line.substr(1, 2))
        char lhs = line[0];
        std::vector<std::vector<char>> rhs;
        std::vector<char> prod;
        for(int j = 3; j < line.size(); j++) {
            if(line[j] == ' ') continue;
            if(line[j] == '|') {
                rhs.push_back(prod);
                prod.clear();
            } else {
                prod.push_back(line[j]);
            }
        }
        rhs.push_back(prod);
        bool correct_prod = true;
        for(auto p : rhs) {
            if(p.empty()) {
                correct_prod = false;
                break;
            }
        }
        if(!correct_prod || rhs.empty()) {
            std::cerr << "Invalid production: " << line << std::endl;
            return 1;
        }
        if(i == 0) ssl = lhs;
        prods[lhs] = rhs;
        done[lhs] = false;
    }

    for(auto it : prods) {
        for(auto prod : it.second) {
            if(!isupper(prod[0])) {
                first[it.first].insert(prod[0]);
            }
        }
    }

    for(auto it : done) {
        if(!it.second) {
            compute_first(prods, first, it.first, done);
        }
    }

    follow[ssl].insert('$');

    for(auto it : prods) {
        for(auto prod : it.second) {
            for(int i = 0; i < prod.size() - 1; i++) {
                if(isupper(prod[i])) {
                    if(isupper(prod[i + 1])) {
                        int j = i + 1;
                        while (j < prod.size()) {
                            if(!isupper(prod[j])) {
                                follow[prod[i]].insert(prod[j]);
                                break;
                            }
                            bool is_eps = false;
                            for(char ch : first[prod[j]]) {
                                if(!EPSILON(ch)) follow[prod[i]].insert(ch);
                                else is_eps = true;
                            }
                            if(is_eps) {
                                j++;
                            } else {
                                break;
                            }
                        }
                    } else {
                        if(!EPSILON(prod[i + 1])) follow[prod[i]].insert(prod[i + 1]);
                    }
                }
            }
        }
    }

    for(auto it : prods) {
        compute_follow(prods, follow, first, it.first);
    }

    std::map<std::pair<char,char>, std::pair<char, std::vector<char>>> table;

    for(auto it : prods) {
        char non_terminal = it.first;
        for(auto prod : it.second) {
            char ch = prod[0];
            if(isupper(ch)) {
                int i = 0;
                while(i < prod.size()) {
                    bool is_eps = false;
                    for(char c : first[ch]) {
                        if(EPSILON(c)) {
                            is_eps = true;
                        } else {
                            table[{non_terminal, c}] = {non_terminal, prod};
                        }
                    }
                    if(is_eps) {
                        i++;
                    } else {
                        break;
                    }
                }
                if(i == prod.size()) {
                    for(char c : follow[non_terminal]) {
                        table[{non_terminal, c}] = {non_terminal, prod};
                    }
                }
            } else {
                if(!EPSILON(ch)) {
                    table[{non_terminal, ch}] = {non_terminal, prod};
                } else {
                    for(auto ch : follow[non_terminal]) {
                        table[{non_terminal, ch}] = {non_terminal, prod};
                    }
                }
            }
        }
    }

    for(auto it : table) {
        std::cout << "M[" << it.first.first << ", " << it.first.second << "] = ";
        std::cout << it.second.first << "->";
        for(char ch : it.second.second) {
            std::cout << ch;
        }
        std::cout << std::endl;
    }

    std::string input;
    std::cout << "Enter the string to parse (with $ at the end): ";
    std::cin >> input;
    input += "$";
    std::cout << std::endl;

    std::stack<char> stack;
    stack.push('$');
    stack.push(ssl);

    i = 0;
    while(i < input.size()) {
        if(stack.top() == '$' && input[i] == '$') {
            std::cout << "SUCCESS: parse tree can be created for the given grammar and string" << std::endl;
            return 0;
        }
        if(stack.top() == input[i]) {
            stack.pop();
            i++;
            continue;
        }
        if(table.find({stack.top(), input[i]}) == table.end()) {
            std::cout << "ERROR: Given string is not part of the grammar" << std::endl;
            return 1;
        } else {
            std::pair<char, std::vector<char>> prod = table[{stack.top(), input[i]}];
            std::cout << prod.first << " Expands to ";
            for(auto ch : prod.second) {
                std::cout << ch;
            }
            std::cout << std::endl;
            stack.pop();
            for(int j = prod.second.size() - 1; j >= 0; j--) {
                if(!EPSILON(prod.second[j])) stack.push(prod.second[j]);
            }
        }
    }
    std::cout << "ERROR: Given string is not part of the grammar" << std::endl;
    return 1;
}