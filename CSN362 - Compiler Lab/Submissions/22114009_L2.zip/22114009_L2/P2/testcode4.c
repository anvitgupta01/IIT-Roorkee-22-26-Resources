for (i=1;i<=5;i++) {
	printf("Number:%d\n",i);