int main() {
    int anvit = 0;
    \t \r;
    printf("%d",anvit);
    return 0;
}