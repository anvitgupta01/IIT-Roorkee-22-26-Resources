int main() {
    int n=-7;
    if (n < 0)
        printf("NEGATIVE");
    else 
        printf("NOT NEGATIVE");
    return 0;
}