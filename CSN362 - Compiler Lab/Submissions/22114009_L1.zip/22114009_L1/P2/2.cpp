#include <bits/stdc++.h>
using namespace std;

// isalpha function is used to check whether a character is a alphanumeric or not.

bool Operator(char x) {
  switch (x) {
  case '+':
  case '-':
  case '/':
  case '*':
  case '^':
  case '%':
    return true;
  }
  return false;
}

string prefixToInfix(string pre_exp) {
  stack<string> s;
  int length = pre_exp.size();

  for (int i = length - 1; i >= 0; i--) {
    if (Operator(pre_exp[i])) {
      string op1 = s.top();   s.pop();
      string op2 = s.top();   s.pop();
      string temp = "(" + op1 + pre_exp[i] + op2 + ")";
      s.push(temp);
    } else {
      s.push(string(1, pre_exp[i]));
    }
  }

  return s.top();
}

bool isOperator(char c)
{
    return (!isalpha(c) && !isdigit(c));
}

int getPriority(char C)
{
    if (C == '-' || C == '+')
        return 1;
    else if (C == '*' || C == '/')
        return 2;
    else if (C == '^')
        return 3;
    return 0;
}

string infixToPostfix(string infix)
{
    infix = '(' + infix + ')';
    int l = infix.size();
    stack<char> char_stack;
    string output;

    for (int i = 0; i < l; i++) {
        if (isalpha(infix[i]) || isdigit(infix[i]))
            output += infix[i];
        else if (infix[i] == '(')
            char_stack.push('(');
        else if (infix[i] == ')') {
            while (char_stack.top() != '(') {
                output += char_stack.top();
                char_stack.pop();
            }
            char_stack.pop();
        }
        else {
            if (isOperator(char_stack.top())) {
                if (infix[i] == '^') {
                    while (getPriority(infix[i]) <= getPriority(char_stack.top())) {
                        output += char_stack.top();
                        char_stack.pop();
                    }
                }
                else {
                    while (getPriority(infix[i]) < getPriority(char_stack.top())) {
                        output += char_stack.top();
                        char_stack.pop();
                    }
                }
                char_stack.push(infix[i]);
            }
        }
    }
    while (!char_stack.empty()) {
        output += char_stack.top();
        char_stack.pop();
    }
    return output;
}

string infixToPrefix(string infix)
{
    int l = infix.size();
    reverse(infix.begin(), infix.end());

    for (int i = 0; i < l; i++) {
        if (infix[i] == '(') {
            infix[i] = ')';
        }
        else if (infix[i] == ')') {
            infix[i] = '(';
        }
    }

    string prefix = infixToPostfix(infix);
    reverse(prefix.begin(), prefix.end());

    return prefix;
}

int main()
{
    cout << "Enter 1 for infix to prefix and 0 for prefix to infix " << endl;
    int choose;
    cin >> choose;
    if (choose == 1) {
        string infix;
        cout << "Enter infix expression: ";
        cin >> infix;
    
        string prefix = infixToPrefix(infix);
        cout << "Prefix expression: " << prefix << endl;
    } else if (choose == 0) {
        string prefix;
        cout << "Enter prefix expression: ";
        cin >> prefix;

        string infix = prefixToInfix(prefix);
        cout << "Infix expression: " << infix << endl;
    } 

    
}
