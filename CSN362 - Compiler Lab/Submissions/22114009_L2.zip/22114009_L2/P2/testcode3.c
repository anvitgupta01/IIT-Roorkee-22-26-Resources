char d = 1200; printf("%d ",d);
 