import copy


def Augmentation(rules, nonterm_userdef, start_symbol):
    newRules = []
    newChar = start_symbol + "'"
    while (newChar in nonterm_userdef):
        newChar += "'"

    newRules.append([newChar, ['.', start_symbol]])

    for rule in rules:
        k = rule.split("->")
        lhs = k[0].strip()
        rhs = k[1].strip()

        multirhs = rhs.split('|')
        for rhs1 in multirhs:
            rhs1 = rhs1.strip().split()
            rhs1.insert(0, '.')
            newRules.append([lhs, rhs1])
    return newRules

def Closure(input_state, dotSymbol):
    global start_symbol, separatedRulesList
    closureSet = []

    if dotSymbol == start_symbol:
        for rule in separatedRulesList:
            if rule[0] == dotSymbol:
                closureSet.append(rule)
    else:
        closureSet = input_state

    prevLen = -1
    while prevLen != len(closureSet):
        prevLen = len(closureSet)
        tempClosureSet = []
        for rule in closureSet:
            indexOfDot = rule[1].index('.')
            if rule[1][-1] != '.':
                dotPointsHere = rule[1][indexOfDot + 1]
                for in_rule in separatedRulesList:
                    if dotPointsHere == in_rule[0] and in_rule not in tempClosureSet:
                        tempClosureSet.append(in_rule)
        for rule in tempClosureSet:
            if rule not in closureSet:
                closureSet.append(rule)
    return closureSet

def compute_GOTO(state):
    global statesDict
    generateStatesFor = []
    for rule in statesDict[state]:
        if rule[1][-1] != '.':
            indexOfDot = rule[1].index('.')
            dotPointsHere = rule[1][indexOfDot + 1]
            if dotPointsHere not in generateStatesFor:
                generateStatesFor.append(dotPointsHere)
    if len(generateStatesFor) != 0:
        for symbol in generateStatesFor:
            GOTO(state, symbol)
    return

def GOTO(state, charNextToDot):
    global statesDict, stateCount, stateMap, separatedRulesList

    newState = []
    for rule in statesDict[state]:
        indexOfDot = rule[1].index('.')
        if rule[1][-1] != '.':
            if rule[1][indexOfDot + 1] == charNextToDot:
                shiftedRule = copy.deepcopy(rule)
                shiftedRule[1][indexOfDot] = shiftedRule[1][indexOfDot + 1]
                shiftedRule[1][indexOfDot + 1] = '.'
                newState.append(shiftedRule)

    addClosureRules = []
    for rule in newState:
        indexDot = rule[1].index('.')
        if rule[1][-1] != '.':
            closureRes = Closure(newState, rule[1][indexDot + 1])
            for rule_cl in closureRes:
                if rule_cl not in addClosureRules and rule_cl not in newState:
                    addClosureRules.append(rule_cl)
    for rule in addClosureRules:
        newState.append(rule)

    stateExists = -1
    for state_num in statesDict:
        if statesDict[state_num] == newState:
            stateExists = state_num
            break

    if stateExists == -1:
        stateCount += 1
        statesDict[stateCount] = newState
        stateMap[(state, charNextToDot)] = stateCount
    else:
        stateMap[(state, charNextToDot)] = stateExists
    return

def generateStates(statesDict):
    prev_len = -1
    called_GOTO_on = []
    while (len(statesDict) != prev_len):
        prev_len = len(statesDict)
        keys = list(statesDict.keys())
        for key in keys:
            if key not in called_GOTO_on:
                called_GOTO_on.append(key)
                compute_GOTO(key)
    return

def first(rule):
    global term_userdef, diction
    if len(rule) != 0 and rule is not None:
        if rule[0] in term_userdef:
            return rule[0]
        elif rule[0] == '#':
            return '#'
    if len(rule) != 0:
        if rule[0] in list(diction.keys()):
            fres = []
            rhs_rules = diction[rule[0]]
            for itr in rhs_rules:
                indivRes = first(itr)
                if type(indivRes) is list:
                    for i in indivRes:
                        fres.append(i)
                else:
                    fres.append(indivRes)
            if '#' not in fres:
                return fres
            else:
                newList = []
                fres.remove('#')
                if len(rule) > 1:
                    ansNew = first(rule[1:])
                    if ansNew is not None:
                        if type(ansNew) is list:
                            newList = fres + ansNew
                        else:
                            newList = fres + [ansNew]
                    else:
                        newList = fres
                    return newList
                fres.append('#')
                return fres

def follow(nt):
    global start_symbol, diction
    solset = set()
    if nt == start_symbol:
        solset.add('$')
    for curNT in diction:
        rhs = diction[curNT]
        for subrule in rhs:
            if nt in subrule:
                while nt in subrule:
                    index_nt = subrule.index(nt)
                    subrule = subrule[index_nt + 1:]
                    if len(subrule) != 0:
                        res = first(subrule)
                        if '#' in res:
                            newList = []
                            res.remove('#')
                            ansNew = follow(curNT)
                            if ansNew is not None:
                                if type(ansNew) is list:
                                    newList = res + ansNew
                                else:
                                    newList = res + [ansNew]
                            else:
                                newList = res
                            res = newList
                    else:
                        if nt != curNT:
                            res = follow(curNT)
                    if res is not None:
                        if type(res) is list:
                            for g in res:
                                solset.add(g)
                        else:
                            solset.add(res)
    return list(solset)

def createParseTable(statesDict, stateMap, T, NT):
    global separatedRulesList, diction

    rows = list(statesDict.keys())
    cols = T + ['$'] + NT

    Table = []
    tempRow = ['' for y in range(len(cols))]
    for x in range(len(rows)):
        Table.append(copy.deepcopy(tempRow))

    for entry in stateMap:
        state = entry[0]
        symbol = entry[1]
        a = rows.index(state)
        b = cols.index(symbol)
        if symbol in NT:
            Table[a][b] = Table[a][b] + f"{stateMap[entry]} "
        elif symbol in T:
            Table[a][b] = Table[a][b] + f"S{stateMap[entry]} "

    numbered = {}
    key_count = 0
    for rule in separatedRulesList:
        tempRule = copy.deepcopy(rule)
        tempRule[1].remove('.')
        numbered[key_count] = tempRule
        key_count += 1

    addedR = f"{separatedRulesList[0][0]} -> {separatedRulesList[0][1][1]}"
    rules.insert(0, addedR)
    for rule in rules:
        k = rule.split("->")
        k[0] = k[0].strip()
        k[1] = k[1].strip()
        rhs = k[1]
        multirhs = rhs.split('|')
        for i in range(len(multirhs)):
            multirhs[i] = multirhs[i].strip().split()
        diction[k[0]] = multirhs

    for stateno in statesDict:
        for rule in statesDict[stateno]:
            if rule[1][-1] == '.':
                temp2 = copy.deepcopy(rule)
                temp2[1].remove('.')
                for key in numbered:
                    if numbered[key] == temp2:
                        follow_result = follow(rule[0])
                        for col in follow_result:
                            index = cols.index(col)
                            if key == 0:
                                Table[stateno][index] = "Accept"
                            else:
                                Table[stateno][index] = Table[stateno][index] + f"R{key} "

    print("\nSLR(1) parsing table:\n")
    frmt = "{:>8}" * len(cols)
    print(" ", frmt.format(*cols), "\n")
    j = 0
    for y in Table:
        frmt1 = "{:>8}" * len(y)
        print(f"I{j:>3} " + frmt1.format(*y))
        j += 1

    global parse_table, table_columns, productions
    parse_table = Table
    table_columns = cols
    productions = numbered

def printResult(rules_list):
    for rule in rules_list:
        print(f"{rule[0]} -> {' '.join(rule[1])}")

def printAllGOTO(diction_map):
    for itr in diction_map:
        print(f"GOTO ( I{itr[0]} , {itr[1]} ) = I{stateMap[itr]}")

class Node:
    def __init__(self, symbol, children=None):
        self.symbol = symbol
        self.children = children if children is not None else []

    def display(self, level=0):
        print("  " * level + str(self.symbol))
        for child in self.children:
            child.display(level + 1)

    def __repr__(self):
        return str(self.symbol)

def simulate(input_string):
    tokens = input_string.split()
    tokens.append('$')
    state_stack = [0]
    parse_tree_stack = []
    index = 0

    print("\n--- Starting SLR(1) Parsing Simulation ---")
    while True:
        current_state = state_stack[-1]
        current_token = tokens[index]
        if current_token not in table_columns:
            print(f"Error: Token '{current_token}' not recognized.")
            return None
        col_index = table_columns.index(current_token)
        action = parse_table[current_state][col_index].strip()
        print(f"State Stack: {state_stack}\tTokens: {tokens[index:]}\tAction: {action}")
        if action == "":
            print(f"Error: No action found in state I{current_state} for token '{current_token}'.")
            return None
        if action.startswith("S"):
            parts = action.split()
            act = parts[0]
            next_state = int(act[1:])
            state_stack.append(next_state)
            parse_tree_stack.append(Node(current_token))
            index += 1
        elif action.startswith("R"):
            parts = action.split()
            act = parts[0]
            prod_num = int(act[1:])
            lhs, rhs = productions[prod_num]
            print(f"Reducing using production R{prod_num}: {lhs} -> {' '.join(rhs)}")
            if rhs == ['#']:
                new_node = Node(lhs, [Node('#')])
            else:
                num = len(rhs)
                children = []
                for _ in range(num):
                    state_stack.pop()
                    children.append(parse_tree_stack.pop())
                children.reverse()
                new_node = Node(lhs, children)
            current_state = state_stack[-1]
            if lhs not in table_columns:
                print(f"Error: Nonterminal '{lhs}' not found in parse table columns.")
                return None
            goto_index = table_columns.index(lhs)
            goto_val = parse_table[current_state][goto_index].strip()
            if goto_val == "":
                print(f"Error: No GOTO action for state I{current_state} and nonterminal '{lhs}'.")
                return None
            new_state = int(goto_val)
            state_stack.append(new_state)
            parse_tree_stack.append(new_node)
        elif action == "Accept":
            print("Input string accepted!\n")
            return parse_tree_stack[-1]
        else:
            print(f"Error: Invalid action '{action}' encountered.")
            return None

def read_grammar(filename):
    rules = []
    nonterm_userdef = []
    term_userdef = []
    start_symbol = None

    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if "->" in line:
                rules.append(line)
            elif line.startswith("NonTerminals:"):
                nonterm_userdef = line.split(":")[1].strip().split(", ")
            elif line.startswith("Terminals:"):
                term_userdef = line.split(":")[1].strip().split(", ")
            elif line.startswith("StartSymbol:"):
                start_symbol = line.split(":")[1].strip()

    return rules, nonterm_userdef, term_userdef, start_symbol

# filename = "text.txt"
# rules, nonterm_userdef, term_userdef, start_symbol = read_grammar(filename)

def nonT_input() :
	numT = input("Enter number of non terminals : ")
	numT = int(numT)
	l = []
	print("Give all the non-terminals one by one : ")
	for i in range(numT) :
		t = input()
		l.append(t)
	return l

def T_input() :
	numT = input("Enter number of terminals : ")
	numT = int(numT)
	l = []
	print("Give all the terminals one by one : ")
	for i in range(numT) :
		t = input()
		l.append(t)
	return l

def fileinput():
	file_name = input("Enter the file name for input grammar : ")
	rulesfor = []
	with open(file_name, 'r') as file:
		for line in file:
			rulesfor.append(line.strip())
	return rulesfor

print("Anvit Gupta : 22114009")

rules = fileinput()
nonterm_userdef = nonT_input()
term_userdef = T_input()
start_symbol = nonterm_userdef[0]

print(rules)

print("\nOriginal grammar input:\n")
for r in rules:
    print(r)

print("\nGrammar after Augmentation: \n")
separatedRulesList = Augmentation(rules, nonterm_userdef, start_symbol)
printResult(separatedRulesList)

start_symbol = separatedRulesList[0][0]
print("\nCalculated closure: I0\n")
I0 = Closure(0, start_symbol)
printResult(I0)

statesDict = {}
stateMap = {}
statesDict[0] = I0
stateCount = 0
generateStates(statesDict)

print("\nStates Generated: \n")
for st in statesDict:
    print(f"State I{st}:")
    printResult(statesDict[st])
    print()

print("Result of GOTO computation:\n")
printAllGOTO(stateMap)

diction = {}

createParseTable(statesDict, stateMap, term_userdef, nonterm_userdef)

input_string = input("Enter the input string: ")
print(f"\nInput string for parsing: {input_string}")

parse_tree_root = simulate(input_string)