#include <bits/stdc++.h>
using namespace std;

struct production {
    string lhs;
    vector<vector<string>> rhs;
};

vector<production> grammar;

set<string> nonterminals;
set<string> terminals;

map<string, set<string>> firstSets;

struct LR1Item {
    int prodIndex;
    int altIndex;
    int dotPos;
    set<string> lookaheads;
    
    tuple<int, int, int> core() const {
         return make_tuple(prodIndex, altIndex, dotPos);
    }
    
    bool operator<(const LR1Item &other) const {
         if(prodIndex != other.prodIndex) return prodIndex < other.prodIndex;
         if(altIndex != other.altIndex) return altIndex < other.altIndex;
         if(dotPos != other.dotPos) return dotPos < other.dotPos;
         return lookaheads < other.lookaheads;
    }
    
    bool operator==(const LR1Item &other) const {
         return prodIndex == other.prodIndex &&
                altIndex == other.altIndex &&
                dotPos == other.dotPos &&
                lookaheads == other.lookaheads;
    }
};

struct Action {
    enum ActionType { SHIFT, REDUCE, ACCEPT } type;
    int state;      
    int prodIndex;
    int altIndex;  
};

struct TreeNode {
    string label;
    vector<TreeNode*> children;
};

vector<string> tokenizeRHS(const string &s) {
    vector<string> tokens;
    string token = "";
    for (int i = 0; i < s.size(); i++) {
         char c = s[i];
         if(isalnum(c)) {
             token.push_back(c);
         } else {
             if(!token.empty()) { 
                 tokens.push_back(token); 
                 token = "";
             }
             if(isspace(c)) continue;
             if(c == '|' || c == '(' || c == ')' || c == '+' || c == '*' || c == '-' || c == '/' || c == '^') {
                  string t(1, c);
                  tokens.push_back(t);
             }
         }
    }
    if(!token.empty()) tokens.push_back(token);
    return tokens;
}

void readGrammar(const string &filename) {
    ifstream infile(filename);
    if(!infile) {
         cerr << "Error opening file: " << filename << endl;
         exit(1);
    }
    string line;
    while(getline(infile, line)) {
         if(line.empty()) continue;
         string filtered = "";
         for(auto c: line) { if(c != '\n' && c != '\r') filtered.push_back(c); }
         size_t pos = filtered.find("->");
         if(pos == string::npos) continue;
         string lhs = filtered.substr(0, pos);
         string rhsPart = filtered.substr(pos+2);
         lhs.erase(remove(lhs.begin(), lhs.end(), ' '), lhs.end());
         production prod;
         prod.lhs = lhs;
         size_t start = 0;
         size_t barPos;
         while((barPos = rhsPart.find("|", start)) != string::npos) {
              string alt = rhsPart.substr(start, barPos - start);
              alt.erase(remove(alt.begin(), alt.end(), ' '), alt.end());
              vector<string> tokens = tokenizeRHS(alt);
              prod.rhs.push_back(tokens);
              start = barPos + 1;
         }
         string alt = rhsPart.substr(start);
         alt.erase(remove(alt.begin(), alt.end(), ' '), alt.end());
         vector<string> tokens = tokenizeRHS(alt);
         prod.rhs.push_back(tokens);
         grammar.push_back(prod);
    }
    infile.close();
    if(!grammar.empty()) {
         production aug;
         aug.lhs = "S'";
         vector<string> startSymbol;
         startSymbol.push_back(grammar[0].lhs);
         aug.rhs.push_back(startSymbol);
         grammar.insert(grammar.begin(), aug);
    }
}

void computeSymbols() {
    for(auto &prod: grammar) {
         nonterminals.insert(prod.lhs);
    }
    for(auto &prod: grammar) {
         for(auto &alt: prod.rhs) {
              for(auto &sym: alt) {
                   if(sym != "^" && nonterminals.find(sym) == nonterminals.end()) {
                         terminals.insert(sym);
                   }
              }
         }
    }
    terminals.insert("$");
}

void computeFirstSets() {
    for(auto nt: nonterminals) {
         firstSets[nt] = set<string>();
    }
    for(auto t: terminals) {
         firstSets[t] = {t};
    }
    bool changed = true;
    while(changed) {
         changed = false;
         for(auto &prod: grammar) {
              string A = prod.lhs;
              for(auto &alt: prod.rhs) {
                   bool allEpsilon = true;
                   for(auto &sym: alt) {
                        int before = firstSets[A].size();
                        for(auto s: firstSets[sym]) {
                             if(s != "^")
                                  firstSets[A].insert(s);
                        }
                        if(firstSets[sym].find("^") == firstSets[sym].end()) {
                             allEpsilon = false;
                             break;
                        }
                        int after = firstSets[A].size();
                        if(after > before) changed = true;
                   }
                   if(allEpsilon) {
                        if(firstSets[A].find("^") == firstSets[A].end()){
                             firstSets[A].insert("^");
                             changed = true;
                        }
                   }
              }
         }
    }
}

set<string> firstOfSequence(const vector<string> &seq) {
    set<string> result;
    if(seq.empty()) { result.insert("^"); return result; }
    bool allEpsilon = true;
    for(auto sym: seq) {
         for(auto s: firstSets[sym]) {
              if(s != "^") result.insert(s);
         }
         if(firstSets[sym].find("^") == firstSets[sym].end()) {
              allEpsilon = false;
              break;
         }
    }
    if(allEpsilon) result.insert("^");
    return result;
}

set<LR1Item> closureLR1(const set<LR1Item> &items) {
    map<tuple<int,int,int>, set<string>> itemMap;
    for(auto &item: items) {
         auto key = item.core();
         itemMap[key].insert(item.lookaheads.begin(), item.lookaheads.end());
    }
    bool changed = true;
    while(changed) {
         changed = false;
         vector<tuple<int,int,int>> keys;
         for(auto &entry: itemMap)
             keys.push_back(entry.first);
         for(auto &key: keys) {
              int p = std::get<0>(key);
              int alt = std::get<1>(key);
              int dot = std::get<2>(key);
              vector<string> rhs = grammar[p].rhs[alt];
              if(dot < rhs.size()) {
                   string B = rhs[dot];
                   if(nonterminals.find(B) != nonterminals.end()) {
                        vector<string> beta;
                        for(int i = dot+1; i < rhs.size(); i++) beta.push_back(rhs[i]);
                        set<string> lookSet;
                        for(auto la : itemMap[key]) {
                             vector<string> seq = beta;
                             seq.push_back(la);
                             set<string> firstSeq = firstOfSequence(seq);
                             firstSeq.erase("^"); 
                             lookSet.insert(firstSeq.begin(), firstSeq.end());
                        }
                        for(int j = 0; j < grammar.size(); j++) {
                             if(grammar[j].lhs == B) {
                                  for(int altIndex = 0; altIndex < grammar[j].rhs.size(); altIndex++) {
                                       auto newKey = make_tuple(j, altIndex, 0);
                                       int before = itemMap[newKey].size();
                                       itemMap[newKey].insert(lookSet.begin(), lookSet.end());
                                       int after = itemMap[newKey].size();
                                       if(after > before) changed = true;
                                  }
                             }
                        }
                   }
              }
         }
    }
    set<LR1Item> closureSet;
    for(auto &entry: itemMap) {
         LR1Item item;
         item.prodIndex = std::get<0>(entry.first);
         item.altIndex = std::get<1>(entry.first);
         item.dotPos = std::get<2>(entry.first);
         item.lookaheads = entry.second;
         closureSet.insert(item);
    }
    return closureSet;
}

set<LR1Item> gotoLR1(const set<LR1Item> &I, const string &X) {
    set<LR1Item> J;
    for(auto &item: I) {
         vector<string> rhs = grammar[item.prodIndex].rhs[item.altIndex];
         if(item.dotPos < rhs.size() && rhs[item.dotPos] == X) {
              LR1Item newItem = item;
              newItem.dotPos++;
              J.insert(newItem);
         }
    }
    return closureLR1(J);
}

void constructCanonicalCollection(vector<set<LR1Item>> &states, vector<map<string,int>> &transitions) {
    LR1Item startItem;
    startItem.prodIndex = 0;
    startItem.altIndex = 0;
    startItem.dotPos = 0;
    startItem.lookaheads.insert("$");
    set<LR1Item> startSet = closureLR1({startItem});
    states.push_back(startSet);
    transitions.push_back(map<string,int>());
    
    bool added = true;
    while(added) {
         added = false;
         int sizeStates = states.size();
         for(int i = 0; i < sizeStates; i++) {
              set<string> symbols;
              for(auto &item: states[i]) {
                   vector<string> rhs = grammar[item.prodIndex].rhs[item.altIndex];
                   if(item.dotPos < rhs.size()) {
                        symbols.insert(rhs[item.dotPos]);
                   }
              }
              for(auto &X: symbols) {
                   set<LR1Item> gotoSet = gotoLR1(states[i], X);
                   if(gotoSet.empty()) continue;
                   int j;
                   bool found = false;
                   for(j = 0; j < states.size(); j++) {
                        if(gotoSet == states[j]) { found = true; break; }
                   }
                   if(!found) {
                        states.push_back(gotoSet);
                        transitions.push_back(map<string,int>());
                        j = states.size() - 1;
                        added = true;
                   }
                   transitions[i][X] = j;
              }
         }
    }
}


void mergeStates(const vector<set<LR1Item>> &lr1States, const vector<map<string,int>> &lr1Transitions,
                 vector<set<LR1Item>> &lalrStates, vector<map<string,int>> &lalrTransitions, vector<int> &stateMapping) {
    int n = lr1States.size();
    stateMapping.resize(n, -1);
    vector<set<tuple<int,int,int>>> lr1Cores(n);
    for (int i = 0; i < n; i++) {
         for(auto &item: lr1States[i]) {
              lr1Cores[i].insert(item.core());
         }
    }
    vector<vector<int>> groups;
    vector<bool> grouped(n, false);
    for (int i = 0; i < n; i++) {
         if(grouped[i]) continue;
         vector<int> group;
         group.push_back(i);
         grouped[i] = true;
         for (int j = i+1; j < n; j++) {
              if(lr1Cores[i] == lr1Cores[j]) {
                   group.push_back(j);
                   grouped[j] = true;
              }
         }
         groups.push_back(group);
    }
    for(auto &group: groups) {
         set<LR1Item> merged;
         map<tuple<int,int,int>, LR1Item> coreItemMap;
         for(auto idx: group) {
              for(auto &item: lr1States[idx]) {
                   auto key = item.core();
                   if(coreItemMap.find(key) == coreItemMap.end()) {
                        coreItemMap[key] = item;
                   } else {
                        coreItemMap[key].lookaheads.insert(item.lookaheads.begin(), item.lookaheads.end());
                   }
              }
         }
         for(auto &entry: coreItemMap) {
              merged.insert(entry.second);
         }
         lalrStates.push_back(merged);
         int newIndex = lalrStates.size() - 1;
         for(auto idx: group) {
              stateMapping[idx] = newIndex;
         }
    }
    int m = lalrStates.size();
    lalrTransitions.resize(m);
    for (int i = 0; i < n; i++) {
         int from = stateMapping[i];
         for(auto &trans: lr1Transitions[i]) {
              string symbol = trans.first;
              int target = trans.second;
              int to = stateMapping[target];
              lalrTransitions[from][symbol] = to;
         }
    }
}

vector<string> tokenizeInput(const string &s) {
    return tokenizeRHS(s);
}

TreeNode* simulateParser(const vector<string> &tokens, 
                         const map<int, map<string, Action>> &actionTable,
                         const map<int, map<string,int>> &gotoTable) {
    vector<int> stateStack;
    vector<TreeNode*> nodeStack;
    stateStack.push_back(0);
    int index = 0;
    while(true) {
         int state = stateStack.back();
         string token = (index < tokens.size() ? tokens[index] : "$");
         if(actionTable.find(state) == actionTable.end() ||
            actionTable.at(state).find(token) == actionTable.at(state).end()) {
              cout << "Error: no action for state " << state << " and token \"" << token << "\"" << endl;
              return nullptr;
         }
         Action act = actionTable.at(state).at(token);
         if(act.type == Action::SHIFT) {
              TreeNode* node = new TreeNode();
              node->label = token;
              stateStack.push_back(act.state);
              nodeStack.push_back(node);
              index++;
         } else if(act.type == Action::REDUCE) {
              production prod = grammar[act.prodIndex];
              vector<string> rhs = prod.rhs[act.altIndex];
              TreeNode* parent = new TreeNode();
              parent->label = prod.lhs;
              vector<TreeNode*> children;
              for(int i = 0; i < rhs.size(); i++) {
                   if(!stateStack.empty()) stateStack.pop_back();
                   if(!nodeStack.empty()) {
                        children.push_back(nodeStack.back());
                        nodeStack.pop_back();
                   }
              }
              reverse(children.begin(), children.end());
              parent->children = children;
              int currentState = stateStack.back();
              if(gotoTable.find(currentState) == gotoTable.end() ||
                 gotoTable.at(currentState).find(prod.lhs) == gotoTable.at(currentState).end()) {
                   cout << "Error: no goto for state " << currentState 
                        << " and nonterminal " << prod.lhs << endl;
                   return nullptr;
              }
              int gotoState = gotoTable.at(currentState).at(prod.lhs);
              stateStack.push_back(gotoState);
              nodeStack.push_back(parent);
         } else if(act.type == Action::ACCEPT) {
              if(nodeStack.size() != 1) {
                   cout << "Error: parse tree stack size not 1 at accept." << endl;
                   return nullptr;
              }
              return nodeStack.back();
         }
    }
}

void printTreeASCII(TreeNode* node, const string &prefix = "", bool isLast = true) {
    cout << prefix;
    if (!prefix.empty()) {
        cout << (isLast ? "\\-- " : "|-- ");
    }
    cout << node->label << endl;
    for (size_t i = 0; i < node->children.size(); i++) {
        bool childIsLast = (i == node->children.size() - 1);
        printTreeASCII(node->children[i], prefix + (isLast ? "    " : "|   "), childIsLast);
    }
}


void printParsingTable(const map<int, map<string, Action>> &actionTable, 
                       const map<int, map<string,int>> &gotoTable, int numStates) {
    const int width = 12; 
    cout << "\nLALR Parsing Table:" << endl;
    
    vector<string> termList(terminals.begin(), terminals.end());
    vector<string> nontermList(nonterminals.begin(), nonterminals.end());
    
    cout << setw(width) << "State";
    for(const auto &t: termList)
         cout << setw(width) << t;
    for(const auto &nt: nontermList)
         cout << setw(width) << nt;
    cout << endl;
    
    for (int i = 0; i < numStates; i++) {
         cout << setw(width) << i;
         for(const auto &t: termList) {
              string cell = "";
              if(actionTable.find(i) != actionTable.end() && 
                 actionTable.at(i).find(t) != actionTable.at(i).end()) {
                   Action act = actionTable.at(i).at(t);
                   if(act.type == Action::SHIFT)
                        cell = "s" + to_string(act.state);
                   else if(act.type == Action::REDUCE) {
                        cell = "r(" + grammar[act.prodIndex].lhs + "->";
                        for(auto &sym: grammar[act.prodIndex].rhs[act.altIndex])
                             cell += sym;
                        cell += ")";
                   } else if(act.type == Action::ACCEPT)
                        cell = "acc";
              }
              cout << setw(width) << cell;
         }
         for(const auto &nt: nontermList) {
              string cell = "";
              if(gotoTable.find(i) != gotoTable.end() &&
                 gotoTable.at(i).find(nt) != gotoTable.at(i).end())
                   cell = to_string(gotoTable.at(i).at(nt));
              cout << setw(width) << cell;
         }
         cout << endl;
    }
}


int main() {
     cout << "Anvit Gupta : 22114009" << endl;
    readGrammar("grammar.txt");
    computeSymbols();
    computeFirstSets();
    
    vector<set<LR1Item>> lr1States;
    vector<map<string,int>> lr1Transitions;
    constructCanonicalCollection(lr1States, lr1Transitions);
    
    vector<set<LR1Item>> lalrStates;
    vector<map<string,int>> lalrTransitions;
    vector<int> stateMapping;
    mergeStates(lr1States, lr1Transitions, lalrStates, lalrTransitions, stateMapping);
    
    map<int, map<string, Action>> actionTable;
    map<int, map<string,int>> gotoTable;
    bool conflict = false;
    int numStates = lalrStates.size();
    for (int i = 0; i < numStates; i++) {
         for(auto &trans: lalrTransitions[i]) {
              string symbol = trans.first;
              int target = trans.second;
              if(terminals.find(symbol) != terminals.end()) {
                   if(actionTable[i].find(symbol) != actionTable[i].end()) {
                        conflict = true;
                        break;
                   }
                   Action act;
                   act.type = Action::SHIFT;
                   act.state = target;
                   actionTable[i][symbol] = act;
              } else if(nonterminals.find(symbol) != nonterminals.end()) {
                   gotoTable[i][symbol] = target;
              }
         }
         for(auto &item: lalrStates[i]) {
              vector<string> rhs = grammar[item.prodIndex].rhs[item.altIndex];
              if(item.dotPos == rhs.size()) {
                   if(grammar[item.prodIndex].lhs == "S'") {
                        if(actionTable[i].find("$") != actionTable[i].end()) {
                             conflict = true;
                             break;
                        }
                        Action act;
                        act.type = Action::ACCEPT;
                        actionTable[i]["$"] = act;
                   } else {
                        for(auto &la: item.lookaheads) {
                             if(actionTable[i].find(la) != actionTable[i].end()) {
                                  conflict = true;
                                  break;
                             }
                             Action act;
                             act.type = Action::REDUCE;
                             act.prodIndex = item.prodIndex;
                             act.altIndex = item.altIndex;
                             actionTable[i][la] = act;
                        }
                   }
              }
         }
         if(conflict) break;
    }
    if(conflict) {
         cout << "Grammar has conflicts. LALR parser cannot be created." << endl;
         return 1;
    }
    
    printParsingTable(actionTable, gotoTable, numStates);
    
    cout << "\nEnter input string (tokens separated by space): " << endl;
    
    string inputLine;
    getline(cin, inputLine);
    vector<string> tokens = tokenizeInput(inputLine);
    
    TreeNode* parseTree = simulateParser(tokens, actionTable, gotoTable);
    if(parseTree == nullptr) {
         cout << "Parsing failed." << endl;
         return 1;
    }
    
    cout << "\nLALR Parse Tree:" << endl;
    printTreeASCII(parseTree);
    
    return 0;
}
