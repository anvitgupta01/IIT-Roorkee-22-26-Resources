#include <bits/stdc++.h>
using namespace std;

enum class TokenType {
    KEYWORD,
    IDENTIFIER,
    LITERAL,
    OPERATOR,
    SEPERATOR,
    STRING_LITERAL,
    UNKNOWN,
};

struct Token {
    TokenType type;
    string value;

    Token(TokenType t, const string& v) : type(t) , value(v) {}
};

bool invalid= false;

class LexicalAnalyzer {
private:
    string input;
    size_t position;
    unordered_map<string, TokenType> keywords;

    void initKeywords()
    {
        keywords["int"] = TokenType::KEYWORD;
        keywords["float"] = TokenType::KEYWORD;
        keywords["char"] = TokenType::KEYWORD;
        keywords["if"] = TokenType::KEYWORD;
        keywords["else"] = TokenType::KEYWORD;
        keywords["while"] = TokenType::KEYWORD;
        keywords["return"] = TokenType::KEYWORD;
        keywords["for"] = TokenType::KEYWORD;
    }

    bool isWhitespace(char c)
    {
        return c == ' ' || c == '\t' || c == '\n'
               || c == '\r';
    }

    bool isAlpha(char c)
    {
        return (c >= 'a' && c <= 'z')
               || (c >= 'A' && c <= 'Z');
    }

    bool isDigit(char c) { return c >= '0' && c <= '9'; }

    bool isAlphaNumeric(char c)
    {
        return isAlpha(c) || isDigit(c);
    }

    string getNextWord()
    {
        size_t start = position;
        while (position < input.length()
               && isAlphaNumeric(input[position])) {
            position++;
        }
        return input.substr(start, position - start);
    }

    string getNextNumber()
    {
        size_t start = position;
        bool hasDecimal = false;
        while (position < input.length()
               && (isDigit(input[position])
                   || input[position] == '.')) {
            if (input[position] == '.') {
                if (hasDecimal)
                    break;
                hasDecimal = true;
            }
            position++;
        }
        if (position < input.length()) {
            if(isalpha(input[position])) {
                invalid = true;
            }
        }
        return input.substr(start, position - start);
    }

public:
    LexicalAnalyzer(const string& source)
        : input(source)
        , position(0)
    {
        initKeywords();
    }

    vector<Token> tokenize()
    {
        vector<Token> tokens;

        while (position < input.length()) {
            char currentChar = input[position];
            char currentChar2 = ' ';
            if (position + 1 < input.length()) {
                currentChar2 = input[position+1];
            }

            if (isWhitespace(currentChar)) {
                position++;
                continue;
            }
            if (currentChar == '"') {
                string ans = "\"";
                position++;
                while(position < input.length() && input[position] != '"') {
                    ans += input[position];
                    position++;
                }
                ans += "\"";
                position++;
                tokens.emplace_back(TokenType::STRING_LITERAL, ans);
            }  else if (currentChar == '+' && currentChar2 == '+') {
                tokens.emplace_back(TokenType::OPERATOR, string(2, currentChar));  
                position += 2;
            } else if (currentChar == '-' && currentChar2 == '-') {
                tokens.emplace_back(TokenType::OPERATOR, string(2, currentChar));
                position += 2;
            } else if (currentChar=='<' && currentChar2=='=') {
                tokens.emplace_back(TokenType::OPERATOR, "<=");
                position += 2;
            } else if (currentChar=='>' && currentChar2=='=') {
                tokens.emplace_back(TokenType::OPERATOR, ">=");
                position += 2;
            } else if (currentChar=='-' && isdigit(currentChar2)) {
                position++;
                string ans = "-";
                bool decimal = false;
                while(position<input.length() && (isdigit(input[position]) || (input[position] == '.'))) {
                    if (input[position] == '.') {
                        if (decimal) {
                            break;
                        }
                        decimal = true;
                    }
                    ans += input[position];
                    position++;
                }
                if (decimal) {
                    tokens.emplace_back(TokenType::LITERAL, ans);
                } else {
                    tokens.emplace_back(TokenType::LITERAL, ans);
                }
            } 
            else if (isAlpha(currentChar)) {
                string word = getNextWord();
                if (keywords.find(word) != keywords.end()) {
                    tokens.emplace_back(TokenType::KEYWORD,
                                        word);
                }
                else {
                    tokens.emplace_back(
                        TokenType::IDENTIFIER, word);
                }
            }
            else if (isDigit(currentChar)) {
                string number = getNextNumber();
                if (invalid == true) {
                    while(position < input.length() && isalnum(input[position])) {
                        number += input[position];
                        position ++;
                    }
                    tokens.emplace_back(TokenType::UNKNOWN, number);
                    invalid = false;
                    continue;
                }
                if (number.find('.') != string::npos) {
                    tokens.emplace_back(
                        TokenType::LITERAL, number);
                }
                else {
                    tokens.emplace_back(
                        TokenType::LITERAL, number);
                }
            }
            else if (currentChar == '+'
                     || currentChar == '-'
                     || currentChar == '*'
                     || currentChar == '/'
                     || currentChar == '=' || currentChar == '<' || currentChar == '>' || currentChar=='[' || currentChar==']' || currentChar == ',') {
                tokens.emplace_back(TokenType::OPERATOR,
                                    string(1, currentChar));
                position++;
            }
            else if (currentChar == '('
                     || currentChar == ')'
                     || currentChar == '{'
                     || currentChar == '}'
                     || currentChar == ';') {
                tokens.emplace_back(TokenType::SEPERATOR,
                                    string(1, currentChar));
                position++;
            }
            else {
                tokens.emplace_back(TokenType::UNKNOWN,
                                    string(1, currentChar));
                position++;
            }
        }

        return tokens;
    }
};

string getTokenTypeName(TokenType type)
{
    switch (type) {
        case TokenType::KEYWORD:
            return " IS A KEYWORD";
        case TokenType::IDENTIFIER:
            return " IS A VALID IDENTIFIER";
        case TokenType::LITERAL:
            return " IS A LITERAL";
        case TokenType::OPERATOR:
            return " IS AN OPERATOR";
        case TokenType::SEPERATOR:
            return " IS A SEPERATOR";
        case TokenType::STRING_LITERAL:
            return " IS A STRING_LITERAL";
        case TokenType::UNKNOWN:
            return " IS NOT A VALID IDENTIFIER";
        default:
            return "UNDEFINED";
    }
}

void printTokens(const vector<Token>& tokens)
{
    for (const auto& token : tokens) {
        cout << token.value << getTokenTypeName(token.type) << endl;
    }
}

int main()
{
    string sourceCode, sourceFileName, line;
    cout << "Enter the source file name " << endl;
    getline(cin,sourceFileName);

    ifstream sourcefile(sourceFileName);
    if (!sourcefile) {
        cerr << "Cannot open source file" << endl;
        return 1;
    } 

    cout << "Tokens Generate by Lexical Analyzer:" << endl;

    while(getline(sourcefile,line)) {
        sourceCode = line;
        LexicalAnalyzer lexer(sourceCode);
        vector<Token> tokens = lexer.tokenize();
        printTokens(tokens);
    }

    return 0;
}