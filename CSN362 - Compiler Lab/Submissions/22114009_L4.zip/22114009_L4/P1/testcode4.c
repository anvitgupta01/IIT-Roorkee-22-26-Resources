int main () {
    string str = "anvit gupta";
    // this is a comment
}