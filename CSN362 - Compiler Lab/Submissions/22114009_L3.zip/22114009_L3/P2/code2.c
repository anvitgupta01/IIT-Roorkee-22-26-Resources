#include <iostream.h>
using namespace std;

int main() {
    string t = "anvit gupta";
    how are you?
    /t      /r;
    return 1;
}