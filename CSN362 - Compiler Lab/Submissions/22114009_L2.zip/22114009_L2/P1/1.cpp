#include <iostream>
#include <string>
using namespace std;

bool matchesAStar(const string& str) {
    for (char c : str) {
        if (c != 'a') {
            return false;
        }
    }
    return true;
}

bool matchesABPlus(const string& str) {
    bool foundB = false;
    int i = 0;

    while (i < str.length() && str[i] == 'a') {
        i++;
    }

    while (i < str.length() && str[i] == 'b') {
        foundB = true;
        i++;
    }

    return foundB && i == str.length();
}

bool matchesAbb(const string& str) {
    for (size_t i = 0; i < str.length(); ) {
        if (str.substr(i, 3) == "abb") {
            i += 3;
        } else {
            return false;
        }
    }
    return true;
}

int main() {
    string s; 
    cout << "Enter the string to check for regex matching..." << endl;
    getline(cin,s);
    if (matchesAStar(s)) {
        cout << s << " is accepted under the rule 'a*'" << endl;
    } else if (matchesABPlus(s)) {
        cout << s << " is accepted under the rule 'a*b+'" << endl;
    } else if (matchesAbb(s)) {
        cout << s << " is accpeted under the rule 'abb'" << endl;
    } else {
        cout << s << " is not recognized" << endl;
    }
    return 0;
}
